import edu.princeton.cs.algs4.*;

import java.util.Iterator;

public class Solver {

    private Node endNode;

    /**
     * Hamming comparator
     */
    private class HammingBoardComparator implements java.util.Comparator<Node> {

        @Override
        public int compare(Node o1, Node o2) {
            return o1.board.hamming() - o2.board.hamming();
        }
    }

    /**
     * Manhattan comparator
     */
    private class ManhattanBoardComparator implements java.util.Comparator<Node> {

        @Override
        public int compare(Node o1, Node o2) {
            return o1.board.manhattan() - o2.board.manhattan();
        }
    }

    private class Node {
        public Node parentNode;
        public Board board;

        public Node(Node parentNode, Board board) {
            this.parentNode = parentNode;
            this.board = board;
        }
    }

    /**
     * find a solution to the initial board (using the A* algorithm)
     *
     * @param initial
     */
    public Solver(Board initial) {
        if (initial == null) throw new java.lang.NullPointerException("null Board");

        Node tup1 = new Node(new Node(null, null), initial);
        Node tup2 = new Node(new Node(null, null), initial.twin());

        MinPQ<Node> minPq = new MinPQ<Node>(512, new ManhattanBoardComparator());

        minPq.insert(tup2);
        minPq.insert(tup1);

        solver(minPq);
    }


    private boolean solver(MinPQ<Node> minPq) {

        long count = 0;

        while (true) {

            if (++count % (1000) == 0) {
                //StdOut.println(count);
                //StdOut.println("pq size " + minPq.size());
            }

            if (minPq.isEmpty()) {
                this.endNode = null;
                return false;
            }

            Node minNode = minPq.delMin();

            if (minNode.board.isGoal()) {
                this.endNode = minNode;
                //StdOut.println(this.endNode.board);
                return true;
            }

            Iterable<Board> neigBoards = minNode.board.neighbors();

            for (Board neigBoard : neigBoards) {
                if (!neigBoard.equals(minNode.parentNode.board)) {
                    minPq.insert(new Node(minNode, neigBoard));
                }
            }
        }
    }

    private boolean isVisited(Node minNode, Board newBoard) {
        return isVisited(minNode, newBoard, 100);
    }

    private boolean isVisited(Node node, Board newBoard, int deep) {

        if (node.parentNode != null) {
            return false;
        }


        if (newBoard.equals(node.board)) {
            return true;
        } else {
            return isVisited(node.parentNode, newBoard);
        }

    }


    private LinkedBag<Board> filterNonVisited(Queue<Board> currentMoves, Iterable<Board> neighbors) {
        LinkedBag<Board> nonVisNeig = new LinkedBag<Board>();
        for (Board n : neighbors) {

            boolean visited = false;
            for (Board bVisited : currentMoves) {
                if (n.equals(bVisited)) {
                    visited = true;
                    break;
                }
            }

            if (!visited) {
                nonVisNeig.add(n);
            }
        }
        return nonVisNeig;
    }


    /**
     * is the initial board solvable?
     *
     * @return
     */
    public boolean isSolvable() {
        return this.endNode != null;
    }

    /**
     * min number of moves to solve initial board; -1 if unsolvable
     *
     * @return
     */
    public int moves() {

        if (this.endNode == null) {
            return -1;
        } else {
            return this.endNode.board.moves;
        }
    }

    /**
     * sequence of boards in a shortest solution; null if unsolvable
     * <p/>
     * number of moves at least its priority, using either the Hamming or Manhattan priority function
     *
     * @return
     */
    public Iterable<Board> solution() {
        return new NodeIterable(this.endNode);
    }

    /**
     * solve a slider puzzle (given below)
     *
     * @param args
     */
    public static void main(String[] args) {
        // create initial board from file
        In in = new In(args[0]);
        int N = in.readInt();
        int[][] blocks = new int[N][N];
        for (int i = 0; i < N; i++)
            for (int j = 0; j < N; j++)
                blocks[i][j] = in.readInt();
        Board initial = new Board(blocks);

        // solve the puzzle
        Solver solver = new Solver(initial);

        // print solution to standard output
        if (!solver.isSolvable())
            StdOut.println("No solution possible");
        else {
            StdOut.println("Minimum number of moves = " + solver.moves());
            for (Board board : solver.solution())
                StdOut.println(board);
        }
    }


    private class NodeIterable implements Iterable<Board> {
        private Node node;

        public NodeIterable(Node node) {
            this.node = node;
        }

        @Override
        public Iterator<Board> iterator() {
            return new NodeIterator(this.node);
        }
    }


    private class NodeIterator implements Iterator<Board> {
        private Node node;

        public NodeIterator(Node node) {
            this.node = node;
        }

        @Override
        public boolean hasNext() {
            return node != null;
        }

        @Override
        public Board next() {
            Node currNode = node;

            this.node = node.parentNode;

            return currNode.board;
        }
    }

}